import React, { useEffect, useState } from "react";
import axios from "axios";

export default function Users() {
    const [users, setUsers] = useState([]);
    useEffect(() => {
        axios
            .get("https://reqres.in/api/users")
            .then(function (response) {
                console.log(response);
            })
            .catch(function (error) {
                console.log(error);
            });
    }, []);
    return <div>HelloWould</div>;
}