import React, { Component } from "react";
import HelloWould from "./components/screens/HelloWould";
import "./App.css";
import styled from "styled-components";
import ToDo from "./components/screens/ToDo";
import Table from "./components/screens/Table";

class App extends Component {
    render() {
        return (
            <>
                <Heading color="നീല">Nafil</Heading>;
                <SubHeading color="മഞ്ഞ">MSM</SubHeading>;
                <Users />
            </>
        )
    }
}

const Heading = styled.h1`
    font-size: 55px;
    margin-top: 100px;
    text-align:center;
    color: ${({color}) => (color === "മഞ്ഞ" ? "yellow" : "#993")};
    @media all and (max-width: 768px) {
        font-size:23px;
    }
`;

const SubHeading = styled(Heading)`
    font-size: 45px;
    color: ${({color}) => (color === "നീല" ? "blue" : "#993")};
    @media all and (max-width: 768px) {
    font-size:19px;
    }
`;

export default App;